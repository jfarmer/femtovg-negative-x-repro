#!/usr/bin/env python3
"""Freeze the completed sweep, make draw observability explicit, then validate selected cases."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path('/root/femtovg-negative-x-repro')
OUT=ROOT/'out/pi3-389-stress-2026-10-09'
os.chdir(ROOT)
os.environ['PATH']='/root/.cargo/bin:'+os.environ['PATH']
os.environ['CARGO_BUILD_JOBS']='1'
deadline=time.monotonic()+1200
while True:
    try: os.kill(12500,0); alive=True
    except ProcessLookupError: alive=False
    if not alive:
        if not (OUT/'complete.json').exists(): raise RuntimeError('initial job did not complete')
        break
    if time.monotonic()>deadline: raise RuntimeError('initial job timeout')
    time.sleep(2)
def call(argv):
    print('COMMAND '+' '.join(map(str,argv)),flush=True)
    subprocess.run(list(map(str,argv)),check=True)
def source_snapshot(name):
    path=OUT/name
    path.mkdir(exist_ok=True)
    for name in ('workload.rs','stress.rs','stress.py','profile.py','build.rs','signposts.c'):
        shutil.copyfile(ROOT/'profiling'/name,path/name)
def telemetry(phase):
    row=dict(phase=phase,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    for key,argv in [('throttled',['vcgencmd','get_throttled']),('temperature',['vcgencmd','measure_temp']),('uptime',['uptime'])]:
        row[key]=subprocess.check_output(argv,text=True)
    with open(OUT/'telemetry.jsonl','a') as stream: stream.write(json.dumps(row)+'\n')
    print('PHASE '+phase+' '+row['throttled'].strip(),flush=True)
source_snapshot('source-v1')
# Preserve evidence that the first sweep retained the shared draw helpers and
# paint parameter generation even before the explicit stress-branch barrier.
build=json.loads((ROOT/'target/profiling/stress-plain/build.json').read_text())
for label in ('master','fixed'):
    binary=build['binaries'][label]['path']
    lines=subprocess.check_output(['nm','-S','-C',binary],text=True).splitlines()
    selected=[line for line in lines if any(line.endswith(name) for name in (
        'femtovg::Canvas<T>::fill_path_internal','femtovg::Canvas<T>::stroke_path_internal',
        'femtovg::Canvas<T>::fill_transformed_path','femtovg::Canvas<T>::stroke_transformed_path',
        'femtovg::renderer::params::Params::new'))]
    (OUT/('v1-'+label+'-symbols.txt')).write_text('\n'.join(selected)+'\n')
    for line in selected:
        address,size,kind,name=line.split(None,3)
        if 'fill_' not in name and 'stroke_' not in name: continue
        output=subprocess.check_output(['objdump','-d','-C','--start-address='+hex(int(address,16)),
                                       '--stop-address='+hex(int(address,16)+int(size,16)),binary],text=True)
        assert 'Params::new' in output
        (OUT/('v1-'+label+'-'+name.split('::')[-1]+'.asm')).write_text(output)
path=ROOT/'profiling/workload.rs'
source=path.read_text()
old='stress.draw(&mut self.canvas, self.font, &opt.case, &opt.motion, frame);\n            return;'
new='stress.draw(&mut self.canvas, self.font, &opt.case, &opt.motion, frame);\n            black_box(&mut self.canvas);\n            return;'
assert source.count(old)==1
path.write_text(source.replace(old,new))
source_snapshot('source-v2')
configs={c['id']:c for c in json.loads((OUT/'confirm-plan.json').read_text())}
summary=json.loads((OUT/'confirm/summary.json').read_text())
ranked=sorted(summary,key=lambda r:r['paired_change_percent']['median'],reverse=True)
plan=[]
for prefix in ('tiny-path-','cache-glyph-','mixed-'):
    plan.append(configs[next(r for r in ranked if configs[r['case']]['case'].startswith(prefix))['case']])
(OUT/'long-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
call([sys.executable,'profiling/profile.py','prepare','--offline','--out','target/profiling/stress-barrier',
      '--cargo-target-dir','target/profiling/plain/cargo','--base-source','femtovg/gradient-master','--fixed-source','femtovg/gradient-fixed'])
governor=Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor')
original=governor.read_text().strip()
try:
    governor.write_text('performance')
    telemetry('long-validation-begin')
    call([sys.executable,'profiling/stress.py','--plan',OUT/'long-plan.json','--build','target/profiling/stress-barrier/build.json',
          '--out',OUT/'long-validation','--repeats','10','--target-seconds','3','--warmup','16','--cpu','2',
          '--notes','Independent long validation of the greatest nine-pair median per family. Source v2 adds an explicit pre-flush observability barrier to the stress branch; both versions rebuilt. No compilation during measurement. CPU2 at performance/1.2GHz.'])
    telemetry('long-validation-end')
    (OUT/'complete-v2.json').write_text(json.dumps(dict(complete=True,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))+'\n')
finally:
    governor.write_text(original)
    telemetry('long-restored-'+original)
