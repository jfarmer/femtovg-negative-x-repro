#!/usr/bin/env python3
"""One remote job: compile first, then serialize paired measurement phases."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/root/femtovg-negative-x-repro')
OUT = ROOT / 'out/pi3-389-stress-2026-10-09'
os.chdir(ROOT)
os.environ['PATH'] = '/root/.cargo/bin:' + os.environ['PATH']
os.environ['CARGO_BUILD_JOBS'] = '1'
OUT.mkdir(exist_ok=False)
def call(argv):
    print('COMMAND ' + ' '.join(map(str, argv)), flush=True)
    subprocess.run(list(map(str, argv)), check=True)
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
def telemetry(phase):
    row = dict(phase=phase, utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    for name, argv in [('throttled',['vcgencmd','get_throttled']),('temperature',['vcgencmd','measure_temp']),
                       ('uptime',['uptime']),('processes',['ps','-eo','pid,pcpu,comm','--sort=-pcpu'])]:
        row[name] = subprocess.check_output(argv, text=True)
    with open(OUT / 'telemetry.jsonl','a') as stream: stream.write(json.dumps(row) + '\n')
    print('PHASE ' + phase + ' ' + row['throttled'].strip(), flush=True)
plain = 'target/profiling/stress-plain/build.json'
alloc = 'target/profiling/stress-allocations/build.json'
for instrumentation, directory in [('plain','stress-plain'),('allocations','stress-allocations')]:
    call([sys.executable,'profiling/profile.py','prepare','--offline','--instrumentation',instrumentation,
          '--out','target/profiling/'+directory,'--cargo-target-dir','target/profiling/plain/cargo',
          '--base-source','femtovg/gradient-master','--fixed-source','femtovg/gradient-fixed'])
sys.path.insert(0,str(ROOT/'profiling'))
import stress
plan = stress.initial_plan()
save('sweep-plan.json',plan)
# Smoke all cases with short runs, asserting shape IDs/coordinates, schedules and
# normalized variation coordinates match, and counts actually exercise the cases.
build = json.loads((ROOT / plain).read_text())
for config in [plan[0],plan[18],plan[30],plan[52],plan[54],plan[66]]:
    results = []
    for label in ('master','fixed'):
        argv = stress.argv_for(build,label,config,16,16,'bulk')
        result = json.loads(subprocess.check_output(argv,text=True))
        results.append(result)
        save('smoke-'+config['id']+'-'+label+'.json',result)
    assert results[0]['stress'] == results[1]['stress']
    assert results[0]['glyphs_per_frame'] == results[1]['glyphs_per_frame']
    assert results[0]['stress']['draws'] == config['draws']
    if config['case'] == 'cache-glyph-fill':
        assert results[0]['stress']['unique_glyph_representations'] == config['working_set']
governor = Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor')
original = governor.read_text().strip()
save('governor.json',dict(original=original,measurement='performance'))
notes = 'Physical Pi3B; armhf; CPU2; performance governor; no compilation during collection. Full-cycle 16-frame stress motion. CPU-only Void renderer. Search-selected candidates require independent confirmation.'
def measure(phase, planfile, buildfile=plain, repeats=3, seconds=.6, collector='none', events=None, frames_from=None, stages=False):
    telemetry(phase+'-begin')
    argv = [sys.executable,'profiling/stress.py','--plan',OUT/planfile,'--build',buildfile,
            '--out',OUT/phase,'--repeats',repeats,'--target-seconds',seconds,'--warmup',16,'--cpu',2,
            '--collector',collector,'--notes',notes]
    if events: argv += ['--events',events]
    if frames_from: argv += ['--frames-from',OUT/frames_from]
    if stages: argv += ['--measure','stages']
    call(argv)
    telemetry(phase+'-end')
try:
    governor.write_text('performance')
    measure('sweep','sweep-plan.json')
    summary = json.loads((OUT/'sweep/summary.json').read_text())
    ranked = sorted(summary,key=lambda row:row['paired_change_percent']['median'],reverse=True)
    configs = {c['id']:c for c in plan}
    chosen = []
    def choose(row):
        c = configs[row['case']]
        if c not in chosen: chosen.append(c)
    for row in ranked[:6]: choose(row)
    for case in ('tiny-path-fill','tiny-path-stroke','cache-glyph-fill','mixed-fill','mixed-stroke'):
        choose(next(row for row in ranked if configs[row['case']]['case'] == case))
    # Keep matching grouped/shuffled controls for chosen cache/mixed inputs.
    for config in list(chosen):
        if config['case'].startswith(('cache-','mixed-')):
            match = next(c for c in plan if all(c[k]==config[k] for k in config if k not in ('id','order')) and c['order']!=config['order'])
            if match not in chosen: chosen.append(match)
    save('confirm-plan.json',chosen)
    save('selection.json',dict(method='Six largest exploratory paired medians plus worst per case and grouped/shuffled controls; no pairs omitted',
                               ranked=[dict(id=r['case'],percent=r['paired_change_percent']) for r in ranked]))
    measure('confirm','confirm-plan.json',repeats=9,seconds=1.5)
    confirmed = json.loads((OUT/'confirm/summary.json').read_text())
    ordered = sorted(confirmed,key=lambda r:r['paired_change_percent']['median'],reverse=True)
    selected = []
    for case in ('tiny-path-fill','tiny-path-stroke','cache-glyph-fill','mixed-fill','mixed-stroke'):
        selected.append(configs[next(r for r in ordered if configs[r['case']]['case']==case)['case']])
    save('counter-plan.json',selected)
    measure('perf-core','counter-plan.json',repeats=5,seconds=1.5,collector='perf',events='cycles,instructions,branches,branch-misses',frames_from='confirm')
    measure('perf-cache','counter-plan.json',repeats=5,seconds=1.5,collector='perf',events='L1-dcache-loads,L1-dcache-load-misses,L1-icache-load-misses,dTLB-load-misses',frames_from='confirm')
    measure('stages','counter-plan.json',repeats=5,seconds=1.5,frames_from='confirm',stages=True)
    measure('allocations','counter-plan.json',buildfile=alloc,repeats=3,seconds=.001)
    save('complete.json',dict(complete=True,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
finally:
    governor.write_text(original)
    telemetry('restored-'+original)
