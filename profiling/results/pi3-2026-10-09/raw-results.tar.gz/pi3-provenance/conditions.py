import json, pathlib, subprocess, sys
sys.path.insert(0, "/root/femtovg-negative-x-repro")
from profiling.profile import linux_snapshot
out = pathlib.Path("/root/femtovg-negative-x-repro/out")
out.mkdir(exist_ok=True)
record_path = out / "pi3-system.json"
def throttled():
    return subprocess.check_output(["vcgencmd", "get_throttled"], text=True).strip()
if sys.argv[1] == "set":
    paths = sorted(pathlib.Path("/sys/devices/system/cpu/cpufreq").glob("policy*/scaling_governor"))
    record = {"original_governors": {str(p): p.read_text().strip() for p in paths},
              "before": linux_snapshot(), "throttled_before": throttled()}
    with record_path.open("x") as stream:
        json.dump(record, stream, indent=2)
    for p in paths:
        p.write_text("performance")
    record["measurement_start"] = linux_snapshot()
else:
    record = json.loads(record_path.read_text())
    record["measurement_end"] = linux_snapshot()
    record["throttled_after"] = throttled()
    for p, value in record["original_governors"].items():
        pathlib.Path(p).write_text(value)
    record["restored"] = linux_snapshot()
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(sys.argv[1], {k:v["governor"] for k,v in linux_snapshot()["cpu_frequency"].items()}, throttled())
