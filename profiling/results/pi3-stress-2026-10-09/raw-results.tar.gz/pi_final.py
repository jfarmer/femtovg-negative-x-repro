#!/usr/bin/env python3
"""Repeat final timing after all artifact packing, downloads, and builds finish."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/root/femtovg-negative-x-repro');OUT=ROOT/'out/pi3-389-stress-2026-10-09'
os.chdir(ROOT);os.environ['PATH']='/root/.cargo/bin:'+os.environ['PATH']
deadline=time.monotonic()+900
while True:
    try:os.kill(14148,0);alive=True
    except ProcessLookupError:alive=False
    if not alive:
        assert (OUT/'complete-v2.json').exists(),'previous validation failed'
        break
    assert time.monotonic()<deadline,'previous validation timeout'
    time.sleep(2)
subprocess.run([sys.executable,'profiling/profile.py','mark-validation',str(OUT/'long-validation'),
    '--reason','Artifact archiving/download overlapped early measurement. Retained as collection validation only; use the independent long-clean repeat.'],check=True)
governor=Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor');original=governor.read_text().strip()
def telemetry(phase):
    row=dict(phase=phase,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             throttled=subprocess.check_output(['vcgencmd','get_throttled'],text=True),
             temperature=subprocess.check_output(['vcgencmd','measure_temp'],text=True))
    with open(OUT/'telemetry.jsonl','a') as stream:stream.write(json.dumps(row)+'\n')
    print('PHASE '+phase+' '+row['throttled'].strip(),flush=True)
try:
    governor.write_text('performance');telemetry('long-clean-begin')
    subprocess.run([sys.executable,'profiling/stress.py','--plan',str(OUT/'long-plan.json'),
        '--build','target/profiling/stress-barrier/build.json','--out',str(OUT/'long-clean'),
        '--repeats','10','--target-seconds','3','--warmup','16','--cpu','2',
        '--notes','Source v2 with explicit pre-flush barrier. Independent ten-pair repeat of greatest confirmed median per family. No compilation, artifact packing, or downloads during this phase. CPU2; performance/1.2GHz. All complete 16-frame motion cycles.'],check=True)
    telemetry('long-clean-end')
    (OUT/'complete-final.json').write_text(json.dumps(dict(complete=True,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))+'\n')
finally:
    governor.write_text(original);telemetry('final-restored-'+original)
